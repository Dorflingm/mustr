class Join < ActiveRecord::Base
end
